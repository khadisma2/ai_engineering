# Using f-strings with print()
first_name = "ISMAIL"
age = 23
date_of_birth = "1990-01-01"
print(f"Welcome to KHADISMA Couture and Fashion Institute. Your First name is {first_name}, you are {age} years old. Your date of birth is {date_of_birth}.")

# Ask the user for their first name and age
first_name = input("Enter your first name: ")
age = input("Enter your age: ")

# Print a welcome message using an f-string
print(f"Welcome, {first_name}! You are {age} years old.")
