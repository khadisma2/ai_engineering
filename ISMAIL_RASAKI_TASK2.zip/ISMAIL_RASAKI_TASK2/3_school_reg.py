# School Form
first_name = input("Enter your First name: ")
middle_name = input("Enter your middle name: ")
last_name = input("Enter your Last name: ")
class_name = input("class name: ")
local_government_area = input("Local Government Area ")
state_of_origin = input("state of origin ")
print("The fullname of the student is " + first_name + " " + middle_name + " " + last_name + ", is in " + class_name + " class, he is from " + local_government_area + " in " + state_of_origin +" .")
      
# Method 2
# Ask for student's name, class, and state of origin
name = input("Enter the student's name: ")
student_class = input("Enter the student's class: ")
state_of_origin = input("Enter the student's state of origin: ")
print("The student's name is " + name + ", in class " + student_class + ", from " + state_of_origin + ".")
