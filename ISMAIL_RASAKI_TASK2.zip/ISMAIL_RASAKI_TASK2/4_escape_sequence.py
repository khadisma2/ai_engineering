# Ask for the name of a Nigerian dish and the state it is popular in
dish = input("Enter the name of a Nigerian dish: ")
state = input("Enter the state it is popular in: ")
print("The most popular Dish among Ekiti people is: " + dish + " in \nState:\t" + state)
