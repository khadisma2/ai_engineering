# Mixing Data Types
age = int(input("Enter your age: "))
height = float(input("Enter your height in meters: "))
name = input("Enter your name: ")
print(f"My name is {name}, I am {age} years old, and my height is {height:.2f} meters.")
