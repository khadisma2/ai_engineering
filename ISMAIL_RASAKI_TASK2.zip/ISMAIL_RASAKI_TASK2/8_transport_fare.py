# distance and fare per km
distance = float(input("Enter distance in km: "))
fare_per_km = float(input("Enter fare per km: "))
total_fare = distance * fare_per_km
print(f"Total fare: ₦{total_fare:.2f}")
