# festival details
festival_name = input("Enter the festival name: ")
location = input("Enter the location: ")
month_held = input("Enter the month it is held: ")
print("The \"" + festival_name + "\" festival is held in " + location + " during " + month_held + ".")
